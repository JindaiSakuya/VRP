package com.sakuya.vrpquestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VrpQuestionApplication {

    public static void main(String[] args) {
        SpringApplication.run(VrpQuestionApplication.class, args);
    }

}
