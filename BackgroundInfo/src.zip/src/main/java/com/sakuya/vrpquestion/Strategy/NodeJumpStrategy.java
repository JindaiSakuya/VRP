package com.sakuya.vrpquestion.Strategy;

import com.sakuya.vrpquestion.Structure.DeliveryVehicle;

public interface NodeJumpStrategy {
    void jump();
}
