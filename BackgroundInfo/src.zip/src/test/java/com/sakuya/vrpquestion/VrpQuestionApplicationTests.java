package com.sakuya.vrpquestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VrpQuestionApplicationTests {

    @Test
    void contextLoads() {
    }

}
